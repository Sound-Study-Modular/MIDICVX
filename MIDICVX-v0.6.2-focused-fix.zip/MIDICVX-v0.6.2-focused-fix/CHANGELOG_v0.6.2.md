# MIDICVX v0.6.2

Focused regression fix:

- Transport no longer writes the software-controlled status LED.
- ARP status LED is off in LIVE, mode-blinks on selection, then steady in ARP.
- Leaving ARP preserves held notes and rebuilds stock LIVE outputs.
- Voice-switch changes reset stale generated gates/cursors.
- CV2 routing remains explicit: DAC channel 1 + Gate2.
