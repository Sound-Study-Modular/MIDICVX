#include "main.h"

#define MIDI_NOTE_COUNT       128U
#define NO_NOTE               0xFFU
#define ARP_GATE_GAP_MS        2U
#define ARP_GATE_PULSE_MS     40U
#define MODE_BLINK_ON_MS      90U
#define MODE_BLINK_OFF_MS    110U

/* One global arp algorithm, with one engine per physical CV/Gate output. */
typedef struct
{
    uint8_t current_note;
    uint8_t output_note;
    uint8_t direction_up;
    uint8_t gate_pending;
    uint8_t gate_high;
    uint32_t gate_on_time;
    uint32_t gate_off_time;
} arp_voice_t;

static uint8_t held_velocity[MIDI_NOTE_COUNT];
static uint8_t held_channel[MIDI_NOTE_COUNT];
static uint8_t held_count;
static uint8_t note_order[MIDI_NOTE_COUNT];
static uint8_t order_count;

static playback_mode_t playback_mode;
static playback_mode_t last_arp_mode;
static arp_voice_t arp_voice[2];
static uint16_t random_state;

/* Lower red LED mode-indication state. */
static uint8_t mode_blinks_remaining;
static uint8_t mode_blink_led_on;
static uint32_t mode_blink_deadline;

static uint8_t Playback_VoiceSwitchTwo(void)
{
    return ((VOICE_SW_PORT_IN & VOICE_SW_PIN) == 0U);
}

static void Playback_ClearEngine(arp_voice_t *voice)
{
    voice->current_note = NO_NOTE;
    voice->output_note = NO_NOTE;
    voice->direction_up = 1U;
    voice->gate_pending = 0U;
    voice->gate_high = 0U;
    voice->gate_on_time = 0U;
    voice->gate_off_time = 0U;
}

static void Playback_ClearHeld(void)
{
    uint8_t note;

    for(note = 0U; note < MIDI_NOTE_COUNT; note++) {
        held_velocity[note] = 0U;
        held_channel[note] = 0U;
        note_order[note] = NO_NOTE;
    }

    held_count = 0U;
    order_count = 0U;
    Playback_ClearEngine(&arp_voice[0]);
    Playback_ClearEngine(&arp_voice[1]);
}

static void Playback_LiveNoteOn(const midi_msg_t *msg)
{
    if(g_midi_ch[0] == g_midi_ch[1]) {
        MidiCv_NoteOn(msg->data1, msg->data2);
    } else {
        MidiCv_NoteOnSingle((msg->channel == g_midi_ch[0]) ? 0U : 1U,
                            msg->data1,
                            msg->data2);
    }
}

static void Playback_LiveNoteOff(const midi_msg_t *msg)
{
    if(g_midi_ch[0] == g_midi_ch[1]) {
        MidiCv_NoteOff(msg->data1);
    } else {
        MidiCv_NoteOffSingle((msg->channel == g_midi_ch[0]) ? 0U : 1U,
                             msg->data1);
    }
}

static void Playback_GateLow(uint8_t output)
{
    if(output == 0U) {
        GATE1_LOW();
    } else {
        GATE2_LOW();
    }
}

static void Playback_GateHigh(uint8_t output)
{
    if(output == 0U) {
        GATE1_HIGH();
    } else {
        GATE2_HIGH();
    }
}

static void Playback_StopVoice(uint8_t output)
{
    Playback_GateLow(output);
    Playback_ClearEngine(&arp_voice[output]);
}

static void Playback_StartBlink(uint8_t count)
{
    mode_blinks_remaining = count;
    mode_blink_led_on = 1U;
    mode_blink_deadline = g_time + MODE_BLINK_ON_MS;
    MIDI_LED_HIGH();
}

static void Playback_UpdateModeLed(void)
{
    if(playback_mode == PLAYBACK_MODE_LIVE) {
        mode_blinks_remaining = 0U;
        mode_blink_led_on = 0U;
        MIDI_LED_LOW();
        return;
    }

    if(mode_blinks_remaining == 0U) {
        MIDI_LED_HIGH();
        return;
    }

    if((int32_t)(g_time - mode_blink_deadline) < 0) {
        return;
    }

    if(mode_blink_led_on != 0U) {
        MIDI_LED_LOW();
        mode_blink_led_on = 0U;
        mode_blink_deadline = g_time + MODE_BLINK_OFF_MS;
        return;
    }

    mode_blinks_remaining--;
    if(mode_blinks_remaining == 0U) {
        MIDI_LED_HIGH();
        return;
    }

    MIDI_LED_HIGH();
    mode_blink_led_on = 1U;
    mode_blink_deadline = g_time + MODE_BLINK_ON_MS;
}

static void Playback_AddOrder(uint8_t note)
{
    if(order_count < MIDI_NOTE_COUNT) {
        note_order[order_count++] = note;
    }
}

static void Playback_RemoveOrder(uint8_t note)
{
    uint8_t i;

    for(i = 0U; i < order_count; i++) {
        if(note_order[i] == note) {
            for(; (uint8_t)(i + 1U) < order_count; i++) {
                note_order[i] = note_order[i + 1U];
            }
            order_count--;
            note_order[order_count] = NO_NOTE;
            return;
        }
    }
}

static uint8_t Playback_NoteAllowed(uint8_t note, uint8_t output, uint8_t two_voice)
{
    uint8_t lower_size;
    uint8_t upper_start;
    uint8_t rank = 0U;
    uint8_t n;

    if(held_velocity[note] == 0U) {
        return 0U;
    }

    if(two_voice == 0U) {
        return (output == 0U); /* CV/Gate 1 is the arp. */
    }

    if(held_count <= 1U) {
        return 1U; /* One held note is available to both outputs. */
    }

    /* Odd-sized chords overlap at the middle note. */
    lower_size = (uint8_t)((held_count + 1U) / 2U);
    upper_start = (uint8_t)(held_count / 2U);

    for(n = 0U; n < note; n++) {
        if(held_velocity[n] != 0U) {
            rank++;
        }
    }

    /* Requested routing:
     * CV/Gate 1 (output 0) = upper/high notes arp.
     * CV/Gate 2 (output 1) = lower/low notes arp. */
    if(output == 0U) {
        return (rank >= upper_start);
    }

    return (rank < lower_size);
}

static uint8_t Playback_FirstAllowed(uint8_t output, uint8_t two_voice)
{
    uint8_t note;
    for(note = 0U; note < MIDI_NOTE_COUNT; note++) {
        if(Playback_NoteAllowed(note, output, two_voice) != 0U) {
            return note;
        }
    }
    return NO_NOTE;
}

static uint8_t Playback_LastAllowed(uint8_t output, uint8_t two_voice)
{
    int16_t note;
    for(note = 127; note >= 0; note--) {
        if(Playback_NoteAllowed((uint8_t)note, output, two_voice) != 0U) {
            return (uint8_t)note;
        }
    }
    return NO_NOTE;
}

static uint8_t Playback_NextUp(uint8_t current, uint8_t output, uint8_t two_voice)
{
    uint16_t note;
    uint16_t start = (current == NO_NOTE) ? 0U : ((uint16_t)current + 1U);

    for(note = start; note < MIDI_NOTE_COUNT; note++) {
        if(Playback_NoteAllowed((uint8_t)note, output, two_voice) != 0U) {
            return (uint8_t)note;
        }
    }
    return Playback_FirstAllowed(output, two_voice);
}

static uint8_t Playback_NextDown(uint8_t current, uint8_t output, uint8_t two_voice)
{
    int16_t note;
    int16_t start = (current == NO_NOTE) ? 127 : ((int16_t)current - 1);

    for(note = start; note >= 0; note--) {
        if(Playback_NoteAllowed((uint8_t)note, output, two_voice) != 0U) {
            return (uint8_t)note;
        }
    }
    return Playback_LastAllowed(output, two_voice);
}

static uint8_t Playback_NextPingPong(arp_voice_t *voice,
                                     uint8_t output,
                                     uint8_t two_voice)
{
    uint8_t next;

    if(voice->current_note == NO_NOTE) {
        voice->direction_up = 1U;
        return Playback_FirstAllowed(output, two_voice);
    }

    if(voice->direction_up != 0U) {
        next = Playback_NextUp(voice->current_note, output, two_voice);
        if(next <= voice->current_note) {
            voice->direction_up = 0U;
            next = Playback_NextDown(voice->current_note, output, two_voice);
        }
    } else {
        next = Playback_NextDown(voice->current_note, output, two_voice);
        if(next >= voice->current_note) {
            voice->direction_up = 1U;
            next = Playback_NextUp(voice->current_note, output, two_voice);
        }
    }

    return next;
}

static uint16_t Playback_Random16(void)
{
    /* xorshift16: small, fast and deterministic on AVR. */
    random_state ^= (uint16_t)(random_state << 7);
    random_state ^= (uint16_t)(random_state >> 9);
    random_state ^= (uint16_t)(random_state << 8);
    if(random_state == 0U) {
        random_state = 0xA361U;
    }
    return random_state;
}

static uint8_t Playback_NextRandom(uint8_t current, uint8_t output, uint8_t two_voice)
{
    uint8_t note;
    uint8_t candidate_count = 0U;
    uint8_t allowed_count = 0U;
    uint8_t choice;

    for(note = 0U; note < MIDI_NOTE_COUNT; note++) {
        if(Playback_NoteAllowed(note, output, two_voice) != 0U) {
            allowed_count++;
            if(note != current) {
                candidate_count++;
            }
        }
    }

    if(allowed_count == 0U) {
        return NO_NOTE;
    }
    if(allowed_count == 1U) {
        return Playback_FirstAllowed(output, two_voice);
    }

    /* Choose among allowed notes excluding the current note. */
    choice = (uint8_t)(Playback_Random16() % candidate_count);
    for(note = 0U; note < MIDI_NOTE_COUNT; note++) {
        if(note != current && Playback_NoteAllowed(note, output, two_voice) != 0U) {
            if(choice == 0U) {
                return note;
            }
            choice--;
        }
    }

    return Playback_FirstAllowed(output, two_voice);
}

static uint8_t Playback_NextOrder(uint8_t current, uint8_t output, uint8_t two_voice)
{
    uint8_t i;
    uint8_t current_index = NO_NOTE;

    for(i = 0U; i < order_count; i++) {
        if(note_order[i] == current) {
            current_index = i;
            break;
        }
    }

    for(i = 1U; i <= order_count; i++) {
        uint8_t index = (current_index == NO_NOTE) ? (uint8_t)(i - 1U)
                                                  : (uint8_t)((current_index + i) % order_count);
        uint8_t note = note_order[index];
        if(note != NO_NOTE && Playback_NoteAllowed(note, output, two_voice) != 0U) {
            return note;
        }
    }

    return Playback_FirstAllowed(output, two_voice);
}

static uint8_t Playback_SelectNext(uint8_t output, uint8_t two_voice)
{
    arp_voice_t *voice = &arp_voice[output];

    switch(playback_mode) {
        case PLAYBACK_MODE_ARP_DOWN:
            return Playback_NextDown(voice->current_note, output, two_voice);
        case PLAYBACK_MODE_ARP_PINGPONG:
            return Playback_NextPingPong(voice, output, two_voice);
        case PLAYBACK_MODE_ARP_RANDOM:
            return Playback_NextRandom(voice->current_note, output, two_voice);
        case PLAYBACK_MODE_ARP_ORDER:
            return Playback_NextOrder(voice->current_note, output, two_voice);
        case PLAYBACK_MODE_ARP_UP:
        default:
            return Playback_NextUp(voice->current_note, output, two_voice);
    }
}

static void Playback_ScheduleNote(uint8_t output, uint8_t note)
{
    arp_voice_t *voice = &arp_voice[output];

    if(note == NO_NOTE) {
        Playback_StopVoice(output);
        return;
    }

    /* Gate low now; CV changes during the guaranteed retrigger gap. */
    Playback_GateLow(output);
    DAC_WriteNote(output, note);

    voice->current_note = note;
    voice->output_note = note;
    voice->gate_pending = 1U;
    voice->gate_high = 0U;
    voice->gate_on_time = g_time + ARP_GATE_GAP_MS;
    voice->gate_off_time = 0U;
}

static void Playback_UpdatePedalVoice(void)
{
    int8_t lowest;

    if(playback_mode == PLAYBACK_MODE_LIVE || Playback_VoiceSwitchTwo() != 0U) {
        return;
    }

    /* In ARP + 1 VOICE: CV/Gate 2 is the lowest held regular note. */
    lowest = Playback_GetLowestHeld();
    if(lowest < 0) {
        Playback_StopVoice(1U);
        return;
    }

    /* Physical CV2 is DAC channel 1; physical Gate2 is GATE2. */
    DAC_WriteNote(1U, (uint8_t)lowest);
    GATE2_HIGH();
    arp_voice[1].output_note = (uint8_t)lowest;
    arp_voice[1].current_note = (uint8_t)lowest;
    arp_voice[1].gate_pending = 0U;
    arp_voice[1].gate_high = 1U;
    arp_voice[1].gate_off_time = 0U;
}

void Playback_Init(void)
{
    Playback_ClearHeld();
    playback_mode = PLAYBACK_MODE_LIVE;
    last_arp_mode = PLAYBACK_MODE_ARP_UP;
    random_state = (uint16_t)(0xA361U ^ (uint16_t)g_time);
    mode_blinks_remaining = 0U;
    mode_blink_led_on = 0U;
    mode_blink_deadline = 0U;
}

void Playback_Process(void)
{
    uint8_t output;
    static uint8_t previous_two_voice = 0xFFU;
    uint8_t two_voice = Playback_VoiceSwitchTwo();

    if(playback_mode != PLAYBACK_MODE_LIVE && previous_two_voice != two_voice) {
        /* Routing changed: stop stale gates and restart both arp cursors. */
        Playback_StopVoice(0U);
        Playback_StopVoice(1U);
        Playback_ClearEngine(&arp_voice[0]);
        Playback_ClearEngine(&arp_voice[1]);
        previous_two_voice = two_voice;
    } else if(playback_mode == PLAYBACK_MODE_LIVE) {
        previous_two_voice = two_voice;
    }

    for(output = 0U; output < 2U; output++) {
        if(arp_voice[output].gate_pending != 0U &&
           (int32_t)(g_time - arp_voice[output].gate_on_time) >= 0) {
            Playback_GateHigh(output);
            arp_voice[output].gate_pending = 0U;
            arp_voice[output].gate_high = 1U;
            arp_voice[output].gate_off_time = g_time + ARP_GATE_PULSE_MS;
        }

        /* Arpeggiated gates are short visible pulses.  The 1-voice pedal
         * output deliberately remains high while its lowest note is held. */
        if(arp_voice[output].gate_high != 0U &&
           arp_voice[output].gate_off_time != 0U &&
           (int32_t)(g_time - arp_voice[output].gate_off_time) >= 0) {
            Playback_GateLow(output);
            arp_voice[output].gate_high = 0U;
            arp_voice[output].gate_off_time = 0U;
        }
    }

    /* Continuously enforce the pedal voice.  This also makes switching
     * between the physical 1 VOICE / 2 VOICE positions reliable while
     * notes are already held. */
    Playback_UpdatePedalVoice();
    Playback_UpdateModeLed();
}

static void Playback_RebuildLiveOutputs(void)
{
    uint8_t note;
    midi_msg_t msg;

    /* Reconstruct the stock MidiCv keyboard/voice state from the notes that
     * are still physically held.  This prevents LIVE from appearing dead
     * after leaving ARP while keys remain down. */
    for(note = 0U; note < MIDI_NOTE_COUNT; note++) {
        if(held_velocity[note] == 0U) {
            continue;
        }

        msg.type = MIDI__NOTE_ON;
        msg.channel = held_channel[note];
        msg.data1 = note;
        msg.data2 = held_velocity[note];
        Playback_LiveNoteOn(&msg);
    }
}

void Playback_SetMode(playback_mode_t mode)
{
    if(mode >= PLAYBACK_MODE_COUNT || playback_mode == mode) {
        return;
    }

    /* Silence both generated voices before changing ownership. */
    Playback_StopVoice(0U);
    Playback_StopVoice(1U);
    MidiCv_Reset();

    playback_mode = mode;
    Playback_ClearEngine(&arp_voice[0]);
    Playback_ClearEngine(&arp_voice[1]);

    if(mode == PLAYBACK_MODE_LIVE) {
        mode_blinks_remaining = 0U;
        mode_blink_led_on = 0U;
        MIDI_LED_LOW();

        /* Keep the held-note table and immediately restore normal outputs. */
        Playback_RebuildLiveOutputs();
    } else {
        last_arp_mode = mode;
        random_state ^= (uint16_t)g_time ^ (uint16_t)Transport_GetTickCount();
        Playback_StartBlink((uint8_t)mode);

        /* In one-voice ARP, establish the pedal voice immediately. */
        Playback_UpdatePedalVoice();
    }
}

playback_mode_t Playback_GetMode(void)
{
    return playback_mode;
}

uint8_t Playback_IsArpActive(void)
{
    return (playback_mode != PLAYBACK_MODE_LIVE);
}

void Playback_LongPress(void)
{
    if(playback_mode == PLAYBACK_MODE_LIVE) {
        Playback_SetMode(last_arp_mode);
    } else {
        Playback_SetMode(PLAYBACK_MODE_LIVE);
    }
}

void Playback_ShortPress(void)
{
    playback_mode_t next;

    if(playback_mode == PLAYBACK_MODE_LIVE) {
        return;
    }

    next = (playback_mode_t)((uint8_t)playback_mode + 1U);
    if(next >= PLAYBACK_MODE_COUNT) {
        next = PLAYBACK_MODE_ARP_UP;
    }
    Playback_SetMode(next);
}

void Playback_NoteOn(const midi_msg_t *msg)
{
    uint8_t note;

    if(msg == 0) {
        return;
    }

    note = msg->data1;
    if(note >= MIDI_NOTE_COUNT) {
        return;
    }

    if(msg->data2 == 0U) {
        Playback_NoteOff(msg);
        return;
    }

    if(held_velocity[note] == 0U) {
        held_count++;
        Playback_AddOrder(note);
    }
    held_velocity[note] = msg->data2;
    held_channel[note] = msg->channel;
    random_state ^= (uint16_t)((uint16_t)note << 8) ^ g_time;

    if(playback_mode == PLAYBACK_MODE_LIVE) {
        Playback_LiveNoteOn(msg);
    } else {
        Playback_UpdatePedalVoice();
    }
}

void Playback_NoteOff(const midi_msg_t *msg)
{
    uint8_t note;
    uint8_t output;

    if(msg == 0) {
        return;
    }

    note = msg->data1;
    if(note >= MIDI_NOTE_COUNT) {
        return;
    }

    if(held_velocity[note] != 0U) {
        held_velocity[note] = 0U;
        held_channel[note] = 0U;
        if(held_count != 0U) {
            held_count--;
        }
        Playback_RemoveOrder(note);
    }

    if(playback_mode == PLAYBACK_MODE_LIVE) {
        Playback_LiveNoteOff(msg);
        return;
    }

    for(output = 0U; output < 2U; output++) {
        if(arp_voice[output].current_note == note) {
            arp_voice[output].current_note = NO_NOTE;
        }
    }

    if(held_count == 0U) {
        Playback_StopVoice(0U);
        Playback_StopVoice(1U);
    } else {
        Playback_UpdatePedalVoice();
    }
}

void Playback_TransportTick(void)
{
    uint8_t two_voice;
    uint8_t next;

    if(playback_mode == PLAYBACK_MODE_LIVE) {
        return;
    }

    if(held_count == 0U) {
        Playback_StopVoice(0U);
        Playback_StopVoice(1U);
        return;
    }

    two_voice = Playback_VoiceSwitchTwo();

    if(two_voice == 0U) {
        /* 1 VOICE: CV/Gate 1 arps; CV/Gate 2 holds the lowest note. */
        next = Playback_SelectNext(0U, 0U);
        Playback_ScheduleNote(0U, next);
        Playback_UpdatePedalVoice();
    } else {
        /* 2 VOICE: CV/Gate 1 upper arp, CV/Gate 2 lower arp. */
        next = Playback_SelectNext(0U, 1U);
        Playback_ScheduleNote(0U, next);
        next = Playback_SelectNext(1U, 1U);
        Playback_ScheduleNote(1U, next);
    }
}

uint8_t Playback_GetHeldCount(void)
{
    return held_count;
}

uint8_t Playback_IsNoteHeld(uint8_t note)
{
    if(note >= MIDI_NOTE_COUNT) {
        return 0U;
    }
    return (held_velocity[note] != 0U);
}

uint8_t Playback_GetVelocity(uint8_t note)
{
    if(note >= MIDI_NOTE_COUNT) {
        return 0U;
    }
    return held_velocity[note];
}

int8_t Playback_GetLowestHeld(void)
{
    uint8_t note;
    for(note = 0U; note < MIDI_NOTE_COUNT; note++) {
        if(held_velocity[note] != 0U) {
            return (int8_t)note;
        }
    }
    return -1;
}

int8_t Playback_GetHighestHeld(void)
{
    int16_t note;
    for(note = 127; note >= 0; note--) {
        if(held_velocity[(uint8_t)note] != 0U) {
            return (int8_t)note;
        }
    }
    return -1;
}
