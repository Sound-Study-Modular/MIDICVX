# Changelog

## v0.2.0 — Playback pass-through

- Added a real playback routing layer for Note On and Note Off messages.
- Preserved the original MIDI channel and voice routing exactly.
- Added no new button behavior, EEPROM settings, or playback modes.
- Intended as a hardware-validated baseline before adding the arpeggiator.

## v0.1.0 — Foundation

- Preserved stock runtime behavior.
- Added firmware metadata and versioning.
- Added future EEPROM layout reservation.
- Added 4 KiB bootloader reserve and build-time size guard.
- Updated build/programming defaults for ATmega328 and USBasp `-B 100`.

## v0.6.0
- Five arp modes: Up, Down, Ping-Pong, Random, and Order Played.
- Fixed random selection with an AVR-friendly xorshift PRNG and repeat avoidance.
- Long Program press enters/exits ARP; short press cycles modes only in ARP.
- Lower red LED indicates ARP and confirms the selected mode with 1-5 blinks.
- 1 Voice ARP: CV/Gate 1 arpeggiates; CV/Gate 2 holds the lowest note.
- 2 Voice ARP: CV/Gate 1 arpeggiates the upper subset; CV/Gate 2 the lower subset.
- Nonblocking 2 ms gate-retrigger gap on active arp outputs.
